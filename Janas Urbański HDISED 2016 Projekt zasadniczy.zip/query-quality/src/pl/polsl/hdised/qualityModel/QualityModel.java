package pl.polsl.hdised.qualityModel;

public class QualityModel {
}
