package pl.polsl.hdised;

public class TableNotFoundException extends Exception {

    public TableNotFoundException() {}
}
